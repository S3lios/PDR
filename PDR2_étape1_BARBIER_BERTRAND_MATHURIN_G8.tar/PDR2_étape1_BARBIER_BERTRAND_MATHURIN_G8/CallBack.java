public interface CallBack {
    public void call();
}
